# Besmi Android Build Instructions

## Quick Start
1. Open Android Studio
2. Select "Open an Existing Project"
3. Navigate to and select the `android` folder
4. Wait for Gradle sync to complete
5. Build → Build Bundle(s) / APK(s) → Build APK(s)
6. Select release variant
7. APK will be generated at: android/app/build/outputs/apk/release/app-release.apk

## Project Configuration
- App ID: com.besmi.lashbooking
- App Name: Besmi
- Production Server: https://besmi.replit.app
- Plugins: 7 Capacitor plugins configured

## Features Included
- Mobile-optimized toggle buttons (70px width)
- Enhanced business hours interface
- Complete lash booking system
- Automatic updates from web platform
