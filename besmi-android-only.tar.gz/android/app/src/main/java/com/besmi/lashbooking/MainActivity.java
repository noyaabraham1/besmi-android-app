package com.besmi.lashbooking;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
